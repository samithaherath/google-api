#!/bin/bash

echo "------------------------------------------"
echo "        creating cpu.dat datafiles"
echo "------------------------------------------"
	

matrix_size=( 32 64 128 256 512)
thread_size=( 16 32 128 256 1024)
run_times=30

datafile="cpu.dat"
if [ -e $datafile ] 
	then
		rm -rf $datafile
		touch $datafile
	else
		touch $datafile
	fi
	printf "size   time\n" >> $datafile
	for i in "${matrix_size[@]}"
	do
		:

		TIMES=($(seq 0 $run_times))
		total="0"
		echo "N=$i"
		for j in "${TIMES[@]}"
		do 
			:
			c99 cpu.c -o out -Wincompatible-pointer-types
			result=$(./out $i)
			total=$(bc <<< "scale=10; $total+$result")
			echo "   Runtime ==> $j T=$result"
		done
		avg=$(bc <<< "scale=10; $total/${#TIMES[@]}")
		printf "$i   $avg\n" >> $datafile
		echo "              Average time ===>  = $avg"
	done
	echo "Written data to $datafile"

echo "------------------------------------------"
echo "        creating global.dat datafiles"
echo "------------------------------------------"
	



datafile="global.dat"
if [ -e $datafile ] 
	then
		rm -rf $datafile
		touch $datafile
	else
		touch $datafile
	fi
	printf "size   time\n" >> $datafile
	for i in "${matrix_size[@]}"
	do
		:

		TIMES=($(seq 0 $run_times))
		total="0"
		echo "N=$i"
		for j in "${TIMES[@]}"
		do 
			:
			nvcc global.cu -o out -Wno-deprecated-gpu-targets
			result=$(./out $i)
			total=$(bc <<< "scale=10; $total+$result")
			echo "   Runtime ==> $j T=$result"
		done
		avg=$(bc <<< "scale=10; $total/${#TIMES[@]}")
		printf "$i   $avg\n" >> $datafile
		echo "              Average time ===>  = $avg"
	done
	echo "Written data to $datafile"

echo "------------------------------------------"
echo "        creating shared.dat datafiles"
echo "------------------------------------------"
	



datafile="shared.dat"
if [ -e $datafile ] 
	then
		rm -rf $datafile
		touch $datafile
	else
		touch $datafile
	fi
	printf "size   time\n" >> $datafile
	for i in "${matrix_size[@]}"
	do
		:

		TIMES=($(seq 0 $run_times))
		total="0"
		echo "N=$i"
		for j in "${TIMES[@]}"
		do 
			:
			nvcc shared.cu -o out -Wno-deprecated-gpu-targets
			result=$(./out $i)
			total=$(bc <<< "scale=10; $total+$result")
			echo "   Runtime ==> $j T=$result"
		done
		avg=$(bc <<< "scale=10; $total/${#TIMES[@]}")
		printf "$i   $avg\n" >> $datafile
		echo "              Average time ===>  = $avg"
	done
	echo "Written data to $datafile"

echo "------------------------------------------"
echo "        creating global_thread.dat datafiles"
echo "------------------------------------------"
	



datafile="global_thread.dat"
if [ -e $datafile ] 
	then
		rm -rf $datafile
		touch $datafile
	else
		touch $datafile
	fi
	printf "size   time\n" >> $datafile
	for i in "${thread_size[@]}"
	do
		:

		TIMES=($(seq 0 $run_times))
		total="0"
		
		echo "N=$i"
		for j in "${TIMES[@]}"
		do 
			:
			nvcc global_thread_change.cu -o out -Wno-deprecated-gpu-targets
			result=$(./out $i)
			total=$(bc <<< "scale=10; $total+$result")
			echo "   Runtime ==> $j T=$result"
		done
		avg=$(bc <<< "scale=10; $total/${#TIMES[@]}")
		printf "$i $avg\n" >> $datafile
		echo "              Average time ===>  = $avg"
	done
	echo "Written data to $datafile"



echo ""
echo "creating pdf....."
echo ""


pdflatex Report.tex
pdflatex Report.tex
echo "see report.pdf for the final result...."


