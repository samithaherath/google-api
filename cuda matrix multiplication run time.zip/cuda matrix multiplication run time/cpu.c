#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double runtime=0;
int main (int argc, char **argv)

{
    
    int **ptr1, **ptr2, **ptr3;
    int N, col1, row2, col2;
    int i, j, k;

     N = atoi(argv[1]);

//memory allocating

    ptr1 = (int **) malloc (sizeof (int *) * N);
    ptr2 = (int **) malloc (sizeof (int *) * N);
    ptr3 = (int **) malloc (sizeof (int *) * N);

    for (i = 0; i < N; i++)
        ptr1[i] = (int *) malloc (sizeof (int) * N);
    for (i = 0; i < N; i++)
        ptr2[i] = (int *) malloc (sizeof (int) * N);
    for (i = 0; i < N; i++)
        ptr3[i] = (int *) malloc (sizeof (int) * N);

    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            ptr1[i][j] = rand ()% 1024;
        }
    }
//assigning values to matrix

    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            ptr2[i][j] = rand ()% 1024;
        }
    }
//matrx multiplication and time calculation

clock_t begin = clock();
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
           int temp= 0;
            for (k = 0; k < N; k++){
                temp = temp + ptr1[i][k] * ptr2[k][j];
        }
	ptr3[i][j]=temp;
}
    }
clock_t end = clock();
	runtime =  (double)(end - begin) / CLOCKS_PER_SEC;

    /* Printing the contents of third matrix. 

    printf ("\n\nFinal Matrix :");
    for (i = 0; i < N; i++) {
        printf ("\n\t");
        for (j = 0; j < N; j++)
            printf ("%4d", ptr3[i][j]);
    }*/

   printf("%f\n",runtime);
    return (0);
}
