To get the final report run "run.sh" file

Final report is pdf format called "Report.pdf"

execution files
	cpu.c
	global.cu
	shared.cu
	globalthreadchange.cu

data files
	cpu.dat
	global.dat
	shared.dat
	globalthread.dat

latex file
	Report.tex
